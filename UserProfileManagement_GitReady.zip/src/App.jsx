import React, { useState } from 'react'
import AddUserModal from './components/AddUserModal'
import UserList from './components/UserList'
import ProfileEditor from './components/ProfileEditor'
import { uid, storageGet, storageSet } from './utils/localStorage'

export default function App(){
  const [users, setUsers] = useState(()=>storageGet())
  const [selected, setSelected] = useState(users[0]||null)
  const [showAdd, setShowAdd] = useState(false)

  const addUser = (u)=>{ const nw={...u,id:uid()}; const newList=[...users, nw]; setUsers(newList); storageSet(newList); setSelected(nw); setShowAdd(false) }
  const updateUser = (u)=>{ const newList=users.map(x=>x.id===u.id?u:x); setUsers(newList); storageSet(newList); }
  const deleteUser = (id)=>{ const newList=users.filter(x=>x.id!==id); setUsers(newList); storageSet(newList); if(selected?.id===id) setSelected(null) }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between mb-6"><h1 className="text-2xl font-bold">User Profile Management</h1><button onClick={()=>setShowAdd(true)} className="bg-indigo-600 text-white px-4 py-2 rounded">Add User</button></div>
        <div className="grid md:grid-cols-3 gap-6">
          <UserList users={users} selectedId={selected?.id} onSelect={setSelected} onDelete={deleteUser} />
          <div className="md:col-span-2">{selected? <ProfileEditor user={selected} onSave={updateUser} /> : <div className="bg-white p-10 text-center rounded shadow text-gray-500">Select a user to view/edit profile</div>}</div>
        </div>
        {showAdd && <AddUserModal onClose={()=>setShowAdd(false)} onAdd={addUser} />}
      </div>
    </div>
  )
}
