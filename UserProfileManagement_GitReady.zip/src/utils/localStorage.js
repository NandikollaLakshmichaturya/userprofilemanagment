export function uid(){ return Math.random().toString(36).slice(2,9) }
export function storageGet(key='users_v1'){ try{ const r=localStorage.getItem(key); return r?JSON.parse(r):[] }catch(e){return []} }
export function storageSet(data,key='users_v1'){ localStorage.setItem(key, JSON.stringify(data)) }
