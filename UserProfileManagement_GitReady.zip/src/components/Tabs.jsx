import React from 'react'
export default function Tabs({tabs,active,setActive}){
  return (<div className="flex gap-2">{tabs.map(t=>(<button key={t} onClick={()=>setActive(t)} className={`px-3 py-1 rounded ${active===t?'bg-indigo-100 text-indigo-700':'bg-gray-100'}`}>{t[0].toUpperCase()+t.slice(1)}</button>))}</div>)
}
