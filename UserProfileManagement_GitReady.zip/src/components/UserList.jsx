import React from 'react'
export default function UserList({users,selectedId,onSelect,onDelete}){
  return (
    <div className="bg-white p-4 rounded shadow">
      <h3 className="font-semibold mb-2">Users</h3>
      {users.length===0? <p className="text-gray-500">No users yet</p> : (
        <ul>{users.map(u=>(<li key={u.id} className={`p-2 border-b flex justify-between items-center ${selectedId===u.id?'bg-indigo-50':''}`}><button onClick={()=>onSelect(u)} className="text-left">{u.firstName} {u.lastName}</button><button onClick={()=>onDelete(u.id)} className="text-red-600 text-sm">Delete</button></li>))}</ul>
      )}
    </div>
  )
}
