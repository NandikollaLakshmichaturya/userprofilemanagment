import React, { useState } from 'react'
export default function AddUserModal({onClose,onAdd}){
  const [form, setForm] = useState({firstName:'',lastName:'',email:'',phone:''})
  const handleChange = (k,v)=>setForm({...form,[k]:v})
  const submit = e=>{ e.preventDefault(); onAdd({...form, education:[], skills:[], experience:[]}) }
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center">
      <div className="bg-white p-6 rounded shadow w-full max-w-md">
        <div className="flex justify-between mb-4"><h3 className="font-semibold">Add User</h3><button onClick={onClose}>✕</button></div>
        <form onSubmit={submit} className="space-y-3">
          {['firstName','lastName','email','phone'].map(f=>(<input key={f} value={form[f]} onChange={e=>handleChange(f,e.target.value)} placeholder={f} className="border rounded w-full px-3 py-2" />))}
          <div className="flex justify-end gap-2"><button type="button" onClick={onClose} className="border px-3 py-2 rounded">Cancel</button><button type="submit" className="bg-indigo-600 text-white px-3 py-2 rounded">Add</button></div>
        </form>
      </div>
    </div>
  )
}
